<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            width: 80%;
            text-align: center;
        }

        h1 {
            color: #dc3545;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        li {
            margin-bottom: 20px;
        }

        a {
            text-decoration: none;
            color: #dc3545;
            font-weight: bold;
            font-size: 1.2rem;
            border: 2px solid #dc3545;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        a:hover {
            background-color: #dc3545;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Menu</h1>
        <ul>
            <li><a href="cadastro.html">Cadastro</a></li>
            <br>
            <li><a href="lista.inc.php">Lista de Cadastros</a></li>
        </ul>
    </div>
</body>
</html>
