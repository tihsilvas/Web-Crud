<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário de Cadastro</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 400px;
            text-align: center;
        }
        .success {
            color: green;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>
        <?php
            if (!empty($_POST["nome"]) && !empty($_POST["email"]) && !empty($_POST["cidade"]) && !empty($_POST["estado"]) && !empty($_POST["comentarios"])) {
            include 'conecta_mysql.inc.php';

            $nome = $_POST["nome"];
            $email = $_POST["email"];
            $cidade = $_POST["cidade"];
            $estado = $_POST["estado"];
            $comentarios = $_POST["comentarios"];

            $nome = strtolower($nome);
            $sql_verifica = "SELECT nome FROM cadastro WHERE LOWER(nome) = '$nome'";
            $resultado_verifica = $conexao->query($sql_verifica);
            ?>
            <div class="container">
                <?php if ($resultado_verifica->num_rows > 0 && $erro == 0) {
                    echo "<p class='error'>Nome de usuário já existe. Por favor, escolha outro nome.</p>";
                    echo "<p>Você será redirecionado em 5 segundos...</p>";
                    echo "<meta http-equiv='refresh' content='5;url=cadastro.html'>";  
                    exit;  
                } else {
                    $sql = "INSERT INTO cadastro VALUES ('$nome', '$email', '$cidade', '$estado', '$comentarios')";

                    if ($conexao->query($sql) === TRUE && $erro == 0) {
                        echo "<p class='success'>Usuário incluído com sucesso!</p>";
                        echo "<p>Você será redirecionado em 5 segundos...</p>";
                        echo "<meta http-equiv='refresh' content='5;url=index.php'>";
                    } else {
                        echo "<p class='error'>Erro ao processar a solicitação.</p>";
                        echo "<p>Erro: " . $conexao->error . "</p>";
                    }
                }
                $conexao->close();?>
            </div>
            <?php
        }
        ?>
    </div>
</body>
</html>