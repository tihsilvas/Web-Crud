<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificação de Cadastro</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container2 {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 400px;
            text-align: center;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>
    <?php
        $nome = $_POST["nome"];
        $email = $_POST["email"];
        $cidade = $_POST["cidade"];
        $estado = $_POST["estado"];
        $comentarios = $_POST["comentarios"];
        $erro = 0;
        $mensagens = array();

        if (empty($nome) || strpos($nome, ' ') === FALSE) {
            $mensagens[] = "Favor digitar seu nome corretamente."; 
            $erro = 1;
        }

        if (empty($email) || strlen($email) < 8 || strpos($email, '@') === false) {
            $mensagens[] = "Favor digitar seu email corretamente."; 
            $erro = 1;
        }

        if (empty($cidade)) {
            $mensagens[] = "Favor digitar sua cidade."; 
            $erro = 1;
        }

        if (empty($estado) || strlen($estado) != 2) {
            $mensagens[] = "Favor digitar o estado corretamente."; 
            $erro = 1;
        }

        if (empty($comentarios)) {
            $mensagens[] = "Favor entre com algum comentário."; 
            $erro = 1;
        }

        if ($erro == 1) {
        ?><div class="container2">
            <?php
                foreach ($mensagens as $mensagem) {
                    echo "<p class='error'>$mensagem</p>";
                }
            ?>
        </div><?php
        }
        include 'insere.inc.php';
    ?>
</body>
</html>
