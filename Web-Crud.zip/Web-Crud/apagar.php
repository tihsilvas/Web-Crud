<?php
    $var=$_GET['a'];
    $base=mysqli_connect('localhost', 'root', '', 'bdexemplo') or die ("erro de conexão");
    $apagar="DELETE FROM cadastro WHERE nome='$var'";
    mysqli_query($base, $apagar);
 
    echo("<center><strong><p style='color: red; font-size: 3vh; margin-top: 5vh;'>REGISTRO EXCLUÍDO COM SUCESSO!!</p></center></strong><br>");
    echo("<hr style='margin-top: -2vh; margin-bottom: 5vh; border: 2px solid red;'>");
    include 'lista.inc.php';
?>