<?php
$base=mysqli_connect('localhost', 'root', '', 'bdexemplo') or die("erro de conexão");
$regra1="SELECT * FROM cadastro WHERE estado = 'SP' order by nome";
$regra2="SELECT * FROM cadastro WHERE estado <> 'SP' order by nome";
$res = mysqli_query($base, $regra1); 

echo "<style>

    body{
        opacity: 0;
        animation: fadeIn 1s forwards;
        background-color: #f4f4f4;
    }

    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }

     table {
        width: 100%;
        border-collapse: collapse;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    }

    th, td {
        padding: 12px;
        text-align: left;
    }

    th {
        background-color: #ff7f7f;
        color: white;
    }

    td {
        background-color: #ffe6e6;
    }

    tr:nth-child(even) td {
        background-color: #ffc2c2;
    }

    tr:hover td {
        background-color: #ff9999;
        transition: background-color 0.3s ease;
    }

    a {
        color: #ff4d4d;
        text-decoration: none;
        transition: color 0.3s ease;
    }

    a:hover {
        color: #ff1a1a;
    }
</style>";

echo "<h2><center> Cadastros de usuários do estado de SP </center></h2>

<table>
<tr>
    <th>Nome</th>
    <th>E-mail</th>
    <th>Cidade</th>
    <th>Comentário</th>
    <th></th>
    <th></th>
</tr>";

while ($mostrar = mysqli_fetch_array($res)) { 
    echo "<tr>
        <td>" . $mostrar['nome'] . "</td>
        <td>" . $mostrar['email'] . "</td>
        <td>" . $mostrar['cidade'] . "</td>
        <td>" . $mostrar['comentarios'] . "</td>
        <td><a href='apagar.php?a=".$mostrar['nome']."'>apagar</a></td>
        <td><a href='editar.php?a=".$mostrar['nome']."'>editar</a></td>
    </tr>";
} 
echo "</table>";

$res2 = mysqli_query($base, $regra2); 

echo "<h2><center> Cadastros de usuários de Outros Estados </center></h2>

<table>
<tr>
    <th>Nome</th>
    <th>E-mail</th>
    <th>Cidade</th>
    <th>Comentário</th>
    <th></th>
    <th></th>
</tr>";

while ($mostrar = mysqli_fetch_array($res2)) {
    echo "<tr>
        <td>" . $mostrar['nome'] . "</td>
        <td>" . $mostrar['email'] . "</td>
        <td>" . $mostrar['cidade'] . "</td>
        <td>" . $mostrar['comentarios'] . "</td>
        <td><a href='apagar.php?a=".$mostrar['nome']."'>apagar</a></td>
        <td><a href='editar.php?a=".$mostrar['nome']."'>editar</a></td>
    </tr>";                        
}
echo "</table>";
?>
