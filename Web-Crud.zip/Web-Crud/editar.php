<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Cadastro</title>
    <style>
        body {
            background-color: #f4f4f4;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 90vh;
        }

        h1 {
            margin-bottom: 20px;
            text-align: center;
            color: #fff;
            font-size: 2rem;
            font-weight: bold;
        }

        form {
            max-width: 500px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.5);
            padding: 35px;
            border-radius: 25px;
            background: linear-gradient(to right, #ff8888, #ff6b6b);
            color: #fff;
            animation: fadeIn 1s ease-in-out;
            text-align: center;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        input[type="text"],
        input[type="email"] {
            width: 85%;
            padding: 10px;
            margin-bottom: 20px;
            font-size: 1rem;
            line-height: 1.5;
            color: #242527;
            background-color: rgba(255, 255, 255, 0.8);
            border: none;
            border-radius: 5px;
            transition: background-color 0.3s ease-in-out;
            outline: none;
        }

        input[type="text"]:hover,
        input[type="email"]:hover {
            background-color: rgb(255, 255, 255);
        }

        input[type="text"][readonly],
        input[type="email"][readonly] {
            background-color: #ddd;
            cursor: not-allowed;
        }

        input[type="submit"] {
            width: 90%;
            padding: 10px;
            font-size: 1rem;
            line-height: 1.5;
            color: #fff;
            background-color: #cf5656;
            border: none;
            border-radius: 5px;
            transition: background-color 0.3s ease-in-out;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #ce3c3c;
        }
    </style>
</head>
<body>
    <?php
    $var = $_GET['a'];
    $base = mysqli_connect('localhost', 'root', '', 'bdexemplo') or die("erro de conexão");
    $regra = "SELECT * FROM cadastro WHERE nome = '$var'";
    $res = mysqli_query($base, $regra);
    $mostrar = mysqli_fetch_array($res);
    ?>

    <form method="POST" action="editar1.php">
        <h1>Editar Cadastro</h1>
        <input type="text" size="35" maxlength="256" name="nome" value="<?php echo $mostrar['nome']; ?>" readonly="true"/> <br>
        <input type="email" size="35" maxlength="256" name="email" value="<?php echo $mostrar['email']; ?>" /> <br>
        <input type="text" size="35" maxlength="256" name="cidade" value="<?php echo $mostrar['cidade']; ?>" /> <br>
        <input type="text" size="2" maxlength="2" name="estado" value="<?php echo $mostrar['estado']; ?>" readonly="true"/> <br>
        <input type="submit" value="Atualizar Cadastro" name="enviar">
    </form>
</body>
</html>
